let cards0 = $('#cards_0')
let cards1 = $('#cards_1')
let cards2 = $('#cards_2')

cards1.hide();
cards2.hide();

let id = 0;

function slider(id,val, type){
    if(type === "right") {
        document.getElementById(id).style.marginLeft = val + '%';
        if (val > 0) {
            val--;
            setTimeout('slider("' + id + '",' + val + ',' + '"right")', 5);
        }
    } else if(type === 'left') {
        document.getElementById(id).style.marginLeft = (-val) + '%';
        if (val > 0) {
            val--;
            setTimeout('slider("' + id + '",' + val + ',' + '"left")', 5);
        }
    }
}

$('.but_slider').click(function () {

    if(!this.classList.contains("actif")) {

        Array.prototype.forEach.call($('.but_slider'), function (button, index) {
            if(button.classList.contains("actif")) {
                button.classList.remove("actif");
            }
        })

        this.classList.add("actif");

        let new_id = parseInt(this.id);

        console.log(new_id)

        if(new_id === 0) {
            cards0.show();
            cards1.hide();
            cards2.hide();

            if(new_id > id) slider('cards_0', 35, 'right');
            else slider('cards_0', 35, 'left');

        }else if(new_id === 1) {
            cards0.hide();
            cards1.show();
            cards2.hide();

            if(new_id > id) slider('cards_1', 35, 'right');
            else slider('cards_1', 35, 'left');

        }else if(new_id === 2) {
            cards0.hide();
            cards1.hide();
            cards2.show();

            if (new_id > id) slider('cards_2', 35, 'right');
            else slider('cards_2', 35, 'left');

        }

        id = new_id;

    }

})

